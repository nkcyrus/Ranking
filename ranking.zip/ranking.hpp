#ifndef RANKING_HPP
#define RANKING_HPP

#include <vector>

struct Page {
    int id;
    double score;
};

// On utilise nth_element pour garantir une complexité O(N)
void extraireEtAfficherTop10(double* pi, int N);

#endif