#include "ranking.hpp"
#include <iostream>
#include <algorithm>
#include <iomanip>

bool comparerPages(const Page& a, const Page& b) {
    return a.score > b.score;
}

void extraireEtAfficherTop10(double* pi, int N) {
    std::vector<Page> topPages(N);

    // Initialisation parallèle du vecteur de tri
    #pragma omp parallel for
    for (int i = 0; i < N; ++i) {
        topPages[i].id = i;
        topPages[i].score = pi[i];
    }

    // Isoler les 10 meilleurs (O(N))
    std::nth_element(topPages.begin(), topPages.begin() + 10, topPages.end(), comparerPages);

    // Trier uniquement ces 10 là
    std::sort(topPages.begin(), topPages.begin() + 10, comparerPages);

    std::cout << "\n--- CLASSEMENT FINAL (Top 10) ---" << std::endl;
    for (int i = 0; i < 10; ++i) {
        std::cout << "Rang " << i + 1 << " : Page #" << topPages[i].id 
                  << " (Score: " << std::scientific << std::setprecision(6) << topPages[i].score << ")" << std::endl;
    }
}